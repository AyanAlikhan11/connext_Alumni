const mongoose = require('mongoose');

const eventSchema = new mongoose.Schema({
    title: {
        type: String,
        required: [true, 'Event title is required'],
        trim: true,
        maxlength: [100, 'Title cannot exceed 100 characters']
    },
    description: {
        type: String,
        required: [true, 'Event description is required'],
        maxlength: [1000, 'Description cannot exceed 1000 characters']
    },
    organizer: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    eventType: {
        type: String,
        enum: ['networking', 'workshop', 'conference', 'reunion', 'webinar', 'social'],
        required: true
    },
    dateTime: {
        start: { type: Date, required: true },
        end: { type: Date, required: true }
    },
    location: {
        type: {
            type: String,
            enum: ['physical', 'virtual', 'hybrid'],
            required: true
        },
        address: String,
        onlineLink: String,
        venue: String
    },
    capacity: {
        type: Number,
        min: 1
    },
    attendees: [{
        user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
        registeredAt: { type: Date, default: Date.now },
        status: {
            type: String,
            enum: ['registered', 'attended', 'cancelled'],
            default: 'registered'
        }
    }],
    tags: [String],
    image: String,
    price: {
        amount: { type: Number, default: 0 },
        currency: { type: String, default: 'USD' }
    },
    requirements: {
        minGraduationYear: Number,
        allowedRoles: [String],
        maxAttendees: Number
    },
    status: {
        type: String,
        enum: ['draft', 'published', 'cancelled', 'completed'],
        default: 'draft'
    },
    visibility: {
        type: String,
        enum: ['public', 'private', 'alumni-only'],
        default: 'public'
    }
}, { timestamps: true });

// Indexes
eventSchema.index({ 'dateTime.start': 1 });
eventSchema.index({ organizer: 1 });
eventSchema.index({ eventType: 1 });
eventSchema.index({ tags: 1 });

// Virtual for attendee count
eventSchema.virtual('attendeeCount').get(function() {
    return this.attendees.filter(a => a.status !== 'cancelled').length;
});

// Virtual for available spots
eventSchema.virtual('availableSpots').get(function() {
    if (!this.capacity) return null;
    return this.capacity - this.attendeeCount;
});

// Method to check if user can register
eventSchema.methods.canRegister = function(user) {
    if (this.status !== 'published') return false;
    if (this.visibility === 'alumni-only' && user.role !== 'alumni') return false;
    if (this.requirements.minGraduationYear && user.graduationYear < this.requirements.minGraduationYear) return false;
    if (this.requirements.allowedRoles && !this.requirements.allowedRoles.includes(user.role)) return false;
    
    const alreadyRegistered = this.attendees.some(a => 
        a.user.toString() === user._id.toString() && a.status !== 'cancelled'
    );
    
    return !alreadyRegistered && (this.availableSpots === null || this.availableSpots > 0);
};

module.exports = mongoose.model('Event', eventSchema);