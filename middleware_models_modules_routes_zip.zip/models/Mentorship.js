const mongoose = require('mongoose');

const mentorshipSchema = new mongoose.Schema({
    mentor: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    mentee: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    status: { type: String, enum: ['pending', 'active', 'completed', 'cancelled'], default: 'pending' },
    areas: [String], // Areas of mentorship
    goals: [String],
    startDate: { type: Date },
    endDate: { type: Date },
    meetings: [{
        date: { type: Date },
        notes: { type: String }
    }],
    rating: { type: Number, min: 1, max: 5 },
    feedback: { type: String }
}, { timestamps: true });

module.exports = mongoose.model('Mentorship', mentorshipSchema);