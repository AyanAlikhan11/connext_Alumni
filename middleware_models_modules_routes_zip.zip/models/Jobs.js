const mongoose = require('mongoose');

const jobSchema = new mongoose.Schema({
    title: {
        type: String,
        required: [true, 'Job title is required'],
        trim: true
    },
    company: {
        type: String,
        required: [true, 'Company name is required']
    },
    description: {
        type: String,
        required: [true, 'Job description is required']
    },
    requirements: {
        education: [String],
        experience: { type: Number }, // years
        skills: [String],
        qualifications: [String]
    },
    location: {
        type: {
            type: String,
            enum: ['onsite', 'remote', 'hybrid'],
            required: true
        },
        address: String,
        city: String,
        country: String
    },
    employmentType: {
        type: String,
        enum: ['full-time', 'part-time', 'contract', 'internship', 'freelance'],
        required: true
    },
    salary: {
        min: Number,
        max: Number,
        currency: { type: String, default: 'USD' },
        isPublic: { type: Boolean, default: false }
    },
    postedBy: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    contactEmail: {
        type: String,
        required: true
    },
    applicationUrl: String,
    applicationInstructions: String,
    applicants: [{
        user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
        appliedAt: { type: Date, default: Date.now },
        status: {
            type: String,
            enum: ['pending', 'reviewed', 'accepted', 'rejected'],
            default: 'pending'
        },
        coverLetter: String,
        resume: String
    }],
    tags: [String],
    industry: String,
    experienceLevel: {
        type: String,
        enum: ['entry', 'mid', 'senior', 'executive']
    },
    status: {
        type: String,
        enum: ['active', 'paused', 'closed', 'filled'],
        default: 'active'
    },
    deadline: Date,
    views: { type: Number, default: 0 },
    applicationCount: { type: Number, default: 0 }
}, { timestamps: true });

// Indexes
jobSchema.index({ title: 'text', description: 'text', company: 'text' });
jobSchema.index({ 'location.type': 1 });
jobSchema.index({ employmentType: 1 });
jobSchema.index({ experienceLevel: 1 });
jobSchema.index({ status: 1 });
jobSchema.index({ deadline: 1 });

// Virtual for active status
jobSchema.virtual('isActive').get(function() {
    return this.status === 'active' && (!this.deadline || this.deadline > new Date());
});

// Method to apply for job
jobSchema.methods.apply = function(userId, applicationData) {
    if (!this.isActive) {
        throw new Error('Job is not accepting applications');
    }
    
    const alreadyApplied = this.applicants.some(app => 
        app.user.toString() === userId.toString()
    );
    
    if (alreadyApplied) {
        throw new Error('Already applied to this job');
    }
    
    this.applicants.push({
        user: userId,
        ...applicationData
    });
    
    this.applicationCount += 1;
};

module.exports = mongoose.model('Job', jobSchema);