const express = require('express');
const Job = require('../models/Job');
const auth = require('../middleware/auth');
const router = express.Router();

// Get all jobs
router.get('/', async (req, res) => {
    try {
        const jobs = await Job.find().populate('postedBy', 'firstName lastName company');
        res.json(jobs);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Get single job
router.get('/:id', async (req, res) => {
    try {
        const job = await Job.findById(req.params.id).populate('postedBy', 'firstName lastName company');
        if (!job) return res.status(404).json({ message: 'Job not found' });
        res.json(job);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Create job (protected - only institute and alumni)
router.post('/', auth, async (req, res) => {
    try {
        const job = new Job({
            ...req.body,
            postedBy: req.user.userId
        });
        await job.save();
        res.status(201).json(job);
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
});

// Apply for job (protected)
router.post('/:id/apply', auth, async (req, res) => {
    try {
        const job = await Job.findById(req.params.id);
        if (!job) return res.status(404).json({ message: 'Job not found' });

        // Check if already applied
        const alreadyApplied = job.applicants.find(applicant => applicant.user.toString() === req.user.userId);
        if (alreadyApplied) {
            return res.status(400).json({ message: 'Already applied' });
        }

        job.applicants.push({ user: req.user.userId });
        await job.save();
        res.json({ message: 'Application submitted' });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

module.exports = router;