const express = require('express');
const Mentorship = require('../models/Mentorship');
const auth = require('../middleware/auth');
const router = express.Router();

// Get all mentorship connections for a user
router.get('/', auth, async (req, res) => {
    try {
        const mentorships = await Mentorship.find({
            $or: [{ mentor: req.user.userId }, { mentee: req.user.userId }]
        }).populate('mentor', 'firstName lastName skills currentPosition company')
          .populate('mentee', 'firstName lastName skills currentPosition company');
        res.json(mentorships);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Request mentorship (protected)
router.post('/', auth, async (req, res) => {
    try {
        const { mentorId, areas, goals } = req.body;

        // Check if already exists
        const existing = await Mentorship.findOne({
            mentor: mentorId,
            mentee: req.user.userId,
            status: { $in: ['pending', 'active'] }
        });
        if (existing) {
            return res.status(400).json({ message: 'Mentorship request already exists' });
        }

        const mentorship = new Mentorship({
            mentor: mentorId,
            mentee: req.user.userId,
            areas,
            goals
        });
        await mentorship.save();
        res.status(201).json(mentorship);
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
});

// Update mentorship status (protected)
router.put('/:id', auth, async (req, res) => {
    try {
        const mentorship = await Mentorship.findById(req.params.id);
        if (!mentorship) return res.status(404).json({ message: 'Mentorship not found' });

        // Only mentor can update the status
        if (mentorship.mentor.toString() !== req.user.userId) {
            return res.status(403).json({ message: 'Not authorized' });
        }

        mentorship.status = req.body.status;
        if (req.body.status === 'active') {
            mentorship.startDate = new Date();
        }
        await mentorship.save();
        res.json(mentorship);
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
});

module.exports = router;