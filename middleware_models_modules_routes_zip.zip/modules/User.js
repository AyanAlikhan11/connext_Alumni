const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema({
    // Basic Information
    firstName: { 
        type: String, 
        required: [true, 'First name is required'],
        trim: true,
        maxlength: [50, 'First name cannot exceed 50 characters']
    },
    lastName: { 
        type: String, 
        required: [true, 'Last name is required'],
        trim: true,
        maxlength: [50, 'Last name cannot exceed 50 characters']
    },
    email: { 
        type: String, 
        required: [true, 'Email is required'],
        unique: true,
        lowercase: true,
        match: [/^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/, 'Please enter a valid email']
    },
    password: { 
        type: String, 
        required: [true, 'Password is required'],
        minlength: [6, 'Password must be at least 6 characters']
    },
    
    // Role Information
    role: { 
        type: String, 
        enum: ['alumni', 'student', 'institute'], 
        required: [true, 'Role is required']
    },
    
    // Academic Information
    graduationYear: { 
        type: Number,
        min: [1950, 'Graduation year must be after 1950'],
        max: [new Date().getFullYear() + 5, 'Invalid graduation year']
    },
    studentId: { 
        type: String,
        sparse: true
    },
    institutionName: { 
        type: String,
        trim: true
    },
    degree: { type: String },
    major: { type: String },
    
    // Professional Information
    currentPosition: { type: String },
    company: { type: String },
    industry: { type: String },
    skills: [{ type: String }],
    experience: { type: Number }, // in years
    
    // Profile Information
    profilePicture: { type: String },
    bio: { 
        type: String,
        maxlength: [500, 'Bio cannot exceed 500 characters']
    },
    location: {
        city: { type: String },
        country: { type: String }
    },
    socialLinks: {
        linkedin: { type: String },
        twitter: { type: String },
        github: { type: String }
    },
    
    // Verification Status
    isVerified: { type: Boolean, default: false },
    verificationStatus: {
        type: String,
        enum: ['pending', 'verified', 'rejected'],
        default: 'pending'
    },
    verificationDocument: { type: String },
    appointmentDate: { type: Date },
    
    // Preferences
    emailNotifications: { type: Boolean, default: true },
    jobAlerts: { type: Boolean, default: true },
    mentorshipInterest: { type: Boolean, default: false },
    
    // Statistics
    connections: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
    connectionCount: { type: Number, default: 0 },
    
    // Timestamps
    lastLogin: { type: Date },
    profileCompleted: { type: Boolean, default: false }
}, { 
    timestamps: true 
});

// Indexes for better query performance
userSchema.index({ email: 1 });
userSchema.index({ role: 1 });
userSchema.index({ graduationYear: 1 });
userSchema.index({ skills: 1 });
userSchema.index({ location: 1 });

// Password hashing middleware
userSchema.pre('save', async function(next) {
    if (!this.isModified('password')) return next();
    
    try {
        const salt = await bcrypt.genSalt(12);
        this.password = await bcrypt.hash(this.password, salt);
        next();
    } catch (error) {
        next(error);
    }
});

// Password comparison method
userSchema.methods.comparePassword = async function(candidatePassword) {
    return await bcrypt.compare(candidatePassword, this.password);
};

// Profile completion check
userSchema.methods.checkProfileCompletion = function() {
    const requiredFields = ['firstName', 'lastName', 'email', 'bio', 'currentPosition'];
    const completed = requiredFields.every(field => this[field]);
    this.profileCompleted = completed;
    return completed;
};

// Virtual for full name
userSchema.virtual('fullName').get(function() {
    return `${this.firstName} ${this.lastName}`;
});

// Transform output
userSchema.set('toJSON', {
    virtuals: true,
    transform: function(doc, ret) {
        delete ret.password;
        delete ret.__v;
        return ret;
    }
});

module.exports = mongoose.model('User', userSchema);